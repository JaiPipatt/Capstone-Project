include(CMakeForceCompiler)

set(CMAKE_SYSTEM_NAME Generic)

set(idf_target "esp32c6")
set(idf_path "/Users/prepraestellar/.espressif/v5.4.4/esp-idf")

set(RISCV_TARGETS "esp32c3" "esp32c6" "esp32p4")
set(RISCV_HARD_FLOAT_TARGETS "esp32p4")

if("${idf_target}" IN_LIST RISCV_TARGETS)
    set(CMAKE_SYSTEM_PROCESSOR riscv)
    if("${idf_target}" IN_LIST RISCV_HARD_FLOAT_TARGETS)
        # ESP32-P4 uses hardware floating point
        set(FLAGS "-march=rv32imafc -mabi=ilp32f -ffunction-sections -fdata-sections" CACHE STRING "" FORCE)
    else()
        # ESP32-C3/C6 use soft-float
        set(FLAGS "-ffunction-sections -fdata-sections" CACHE STRING "" FORCE)
    endif()
else()
    set(CMAKE_SYSTEM_PROCESSOR xtensa)
    set(FLAGS "-mlongcalls -ffunction-sections -fdata-sections" CACHE STRING "" FORCE)
endif()

include("/Users/prepraestellar/Documents/GitHub/Capstone-Project/embedding/esp32c6/build/config/sdkconfig.cmake" OPTIONAL)
if(CONFIG_LIBC_PICOLIBC)
    set(FLAGS "${FLAGS} --specs=picolibc.specs" CACHE STRING "" FORCE)
    # `__STDC_WANT_LIB_EXT1__` (C11 Annex K) is only implemented by picolibc.
    # Temporary workaround for ros2/rcutils#552. Remove this once micro-ROS/rcutils picks up ros2/rcutils#555
    add_compile_definitions(__STDC_WANT_LIB_EXT1__=1)
endif()

set(CMAKE_CROSSCOMPILING 1)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
set(PLATFORM_NAME "LwIP")

set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)

set(CMAKE_C_COMPILER /Users/prepraestellar/.espressif/tools/riscv32-esp-elf/esp-14.2.0_20260121/riscv32-esp-elf/bin/riscv32-esp-elf-gcc)
set(CMAKE_CXX_COMPILER /Users/prepraestellar/.espressif/tools/riscv32-esp-elf/esp-14.2.0_20260121/riscv32-esp-elf/bin/riscv32-esp-elf-g++)

if(NOT MICROROS_TOOLCHAIN_FLAGS_APPLIED)
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} ${FLAGS} ${IDF_INCLUDES}" CACHE STRING "" FORCE)
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -fno-exceptions -fno-rtti ${FLAGS} ${IDF_INCLUDES}" CACHE STRING "" FORCE)
    set(MICROROS_TOOLCHAIN_FLAGS_APPLIED TRUE CACHE INTERNAL "micro-ROS toolchain flags were applied")
endif()

add_compile_definitions(ESP_PLATFORM LWIP_IPV4 LWIP_IPV6 PLATFORM_NAME_FREERTOS)

include_directories(
        "/Users/prepraestellar/Documents/GitHub/Capstone-Project/embedding/esp32c6/build/config"
        ${idf_path}/components/soc/${idf_target}/include
    )

if("${idf_target}" IN_LIST RISCV_TARGETS)
    include_directories(
        ${idf_path}/components/riscv/include
    )
endif()

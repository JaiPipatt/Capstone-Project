/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED_Pin|TB_STBY_BOTH_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, TB_2_A_IN1_M3_IL_Pin|TB_2_A_IN2_M3_IL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, TB_1_A_IN1_M1_L_Pin|TB_1_A_IN2_M1_L_Pin|TB_1_B_IN1_M2_R_Pin|TB_1_B_IN2_M2_R_Pin
                          |TB_2_B_IN1_M4_IR_Pin|TB_2_B_IN2_M4_IR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_Pin TB_STBY_BOTH_Pin */
  GPIO_InitStruct.Pin = LED_Pin|TB_STBY_BOTH_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : TB_2_A_IN1_M3_IL_Pin TB_2_A_IN2_M3_IL_Pin */
  GPIO_InitStruct.Pin = TB_2_A_IN1_M3_IL_Pin|TB_2_A_IN2_M3_IL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : TB_1_A_IN1_M1_L_Pin TB_1_A_IN2_M1_L_Pin TB_1_B_IN1_M2_R_Pin TB_1_B_IN2_M2_R_Pin
                           TB_2_B_IN1_M4_IR_Pin TB_2_B_IN2_M4_IR_Pin */
  GPIO_InitStruct.Pin = TB_1_A_IN1_M1_L_Pin|TB_1_A_IN2_M1_L_Pin|TB_1_B_IN1_M2_R_Pin|TB_1_B_IN2_M2_R_Pin
                          |TB_2_B_IN1_M4_IR_Pin|TB_2_B_IN2_M4_IR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 2 */

/* USER CODE END 2 */
